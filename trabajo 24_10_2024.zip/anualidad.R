# Creamos objetos con los valores de entrada:
VF=10000
r=0.01
t=60
# Calculamos la anualidad
Anualidad=A(VF,r,t)
# Imprimimmos el resultado: 
Anualidad