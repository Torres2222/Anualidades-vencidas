# Creamos objetos con los valores de entrada:
VF=10000
A=244.89
t=60
# Calculamos la tasa del periodo
tasa=r(VF,A,t)
# Imprimimos el resultado: 
tasa

