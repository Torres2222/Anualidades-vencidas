# Creamos objetos con los valores de entrada:
VA=10000
r=0.01
t=60
# Calculamos la anualidad
anualidad=A(VA,r,t)
# Imprimimmos el resultado: 
anualidad