# Creamos objetos con los valores de entrada:
A=244.89
r=0.01
t=60
# Calculamos la tasa del periodo
ValorActual=VA(A,r,t)
# Imprimimmos el resultado: 
ValorActual
