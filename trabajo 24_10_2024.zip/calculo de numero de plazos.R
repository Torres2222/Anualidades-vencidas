# Creamos objetos con los valores de entrada:
VA=1000
A=100
r=0.01
# Calculamos el número de pagos
numeroDePagos=t(VA,A,r)
# Imprimimmos el resultado: 
numeroDePagos

