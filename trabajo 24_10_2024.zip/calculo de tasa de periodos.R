# Creamos objetos con los valores de entrada:
VA=3000
A=100
t=36
# Calculamos el número de pagos
tasa=r(VA,A,t)
# Imprimimmos el resultado: 
tasa

