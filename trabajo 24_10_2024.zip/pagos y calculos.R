# Creamos objetos con los valores de entrada:
VF=10000
A=244.89
r=0.01
# Calculamos el numero de pagos
NumeroDePagos=t(VF,A,r)
# Imprimimmos el resultado: 
NumeroDePagos

