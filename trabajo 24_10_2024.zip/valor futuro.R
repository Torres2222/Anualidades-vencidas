# Creamos objetos con los valores de entrada:
A=800
r=1/240
t=84
# Calculamos el valor futuro
ValorFuturo=VF(A,r,t)
# Imprimimmos el resultado: 
ValorFuturo

